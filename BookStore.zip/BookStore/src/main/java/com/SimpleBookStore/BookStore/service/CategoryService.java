package com.SimpleBookStore.BookStore.service;

import com.SimpleBookStore.BookStore.repository.BookRepository;
import com.SimpleBookStore.BookStore.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CategoryService {
    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private CategoryRepository categoryRepository;
}
