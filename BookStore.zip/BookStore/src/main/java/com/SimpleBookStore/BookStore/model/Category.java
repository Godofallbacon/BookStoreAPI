package com.SimpleBookStore.BookStore.model;

public class Category {
}
