package com.SimpleBookStore.BookStore.service;

import com.SimpleBookStore.BookStore.domain.Book;
import com.SimpleBookStore.BookStore.repository.BookRepository;
import com.SimpleBookStore.BookStore.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

@org.springframework.stereotype.Service
public class BookService {
    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    public void createBook(Long categoryId, Book book){
        categoryRepository.findById(categoryId).map(category ->{
            book.setCategory(category);
            return bookRepository.save(book);
        });
    }

    public Iterable<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public ResponseEntity<?> getBookById(Long bookId) {
        Book book = bookrepository.findById(bookId).orElse(null)
    }


    public void updateBookById(Long categoryId, Book book) {
        categoryRepository.findById(categoryId).map(category -> {
            book.setCategory(category);
            return bookRepository.save(book);
        });
    }

    public void deleteBookById(Long bookId){
        bookRepository.deleteById(bookId);
    }
    Iterable<Book> findByCategoryId(long categoryId){
        return bookRepository.findByCategoryId(categoryId);
    }
}
