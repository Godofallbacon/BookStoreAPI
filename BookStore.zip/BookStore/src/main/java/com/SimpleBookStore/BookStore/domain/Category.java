package com.SimpleBookStore.BookStore.domain;

public class Category {
}
