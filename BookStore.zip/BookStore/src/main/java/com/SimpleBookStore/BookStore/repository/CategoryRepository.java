package com.SimpleBookStore.BookStore.repository;


import org.springframework.data.repository.CrudRepository;

public interface CategoryRepository extends CrudRepository<Book, Long> {
}
